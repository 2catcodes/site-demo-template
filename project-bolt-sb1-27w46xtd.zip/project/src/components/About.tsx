import React from 'react';
import { Heart, Users, Dog } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-amber-50 to-orange-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            About Thai Riverside
          </h2>
          <p className="text-lg text-gray-600 leading-relaxed">
            Discover a cozy riverside dining experience where authentic Thai flavors meet the scenic beauty of the Holston River. Our restaurant offers a unique blend of traditional Thai cuisine and warm hospitality in a picturesque setting.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img 
              src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=1"
              alt="Thai Riverside Restaurant Interior"
              className="rounded-lg shadow-xl w-full h-96 object-cover"
            />
          </div>
          <div>
            <h3 className="text-3xl font-bold text-gray-800 mb-6">
              A Riverside Dining Experience
            </h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              At Thai Riverside, we pride ourselves on creating an atmosphere where families, friends, and even furry companions can enjoy exceptional Thai cuisine. Our dog-friendly outdoor seating area overlooks the beautiful Holston River, providing the perfect backdrop for memorable meals.
            </p>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Our friendly staff is dedicated to providing authentic Thai flavors that transport you to the streets of Bangkok, while our signature dishes offer unique twists that have made us a local favorite.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="text-amber-600" size={32} />
            </div>
            <h4 className="text-xl font-bold text-gray-800 mb-3">Authentic Flavors</h4>
            <p className="text-gray-600">
              We blend traditional Thai recipes with fresh, local ingredients to create dishes that are both authentic and memorable.
            </p>
          </div>

          <div className="text-center p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="text-amber-600" size={32} />
            </div>
            <h4 className="text-xl font-bold text-gray-800 mb-3">Friendly Service</h4>
            <p className="text-gray-600">
              Our welcoming staff creates a warm atmosphere where every guest feels like family, ensuring a delightful dining experience.
            </p>
          </div>

          <div className="text-center p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Dog className="text-amber-600" size={32} />
            </div>
            <h4 className="text-xl font-bold text-gray-800 mb-3">Dog-Friendly</h4>
            <p className="text-gray-600">
              Bring your furry friends to enjoy our riverside patio seating, where both you and your pets can relax and dine together.
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Famous For</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {['Pad Thai', 'Drunken Noodles', 'Massaman Curry', 'Pineapple Fried Rice', 'Crab Rangoon'].map((dish) => (
              <span key={dish} className="bg-amber-100 text-amber-800 px-4 py-2 rounded-full font-semibold">
                {dish}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;