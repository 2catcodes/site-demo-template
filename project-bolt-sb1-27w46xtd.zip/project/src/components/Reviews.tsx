import React from 'react';
import { Star, Quote } from 'lucide-react';

const Reviews = () => {
  const reviews = [
    {
      name: "Sarah Johnson",
      rating: 5,
      review: "The best Thai in the Tri-Cities! The flavors are incredible and the riverside setting is absolutely beautiful. Our dog loves the patio seating too!",
      location: "Kingsport, TN"
    },
    {
      name: "Mike Chen",
      rating: 5,
      review: "Better than Thai Noodle Town. The Shrimp Paradise is out of this world, and the staff is so friendly. Highly recommend for a special dinner.",
      location: "Johnson City, TN"
    },
    {
      name: "Jennifer Martinez",
      rating: 5,
      review: "Beautiful views, generous portions, and bold flavors. The Pineapple Fried Rice served in an actual pineapple is a must-try. We'll definitely be back!",
      location: "Bristol, TN"
    },
    {
      name: "David Thompson",
      rating: 5,
      review: "Authentic Thai food with a great atmosphere. The Massaman Curry was perfect, and the riverside location makes it extra special. Great for date nights!",
      location: "Kingsport, TN"
    },
    {
      name: "Lisa Park",
      rating: 5,
      review: "Hidden gem! The Pad Thai is the best I've had outside of Thailand. The service is excellent and the outdoor seating is perfect for families with pets.",
      location: "Elizabethton, TN"
    },
    {
      name: "Robert Wilson",
      rating: 5,
      review: "Fantastic food and amazing views of the Holston River. The Drunken Noodles had the perfect amount of spice. This place is a treasure!",
      location: "Gray, TN"
    }
  ];

  return (
    <section id="reviews" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            What Our Guests Say
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it – hear from our satisfied customers who keep coming back for more.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="flex space-x-1">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="text-amber-400 fill-current" size={20} />
                  ))}
                </div>
              </div>
              
              <div className="relative mb-6">
                <Quote className="absolute -top-2 -left-2 text-amber-200" size={24} />
                <p className="text-gray-700 italic pl-6 leading-relaxed">
                  "{review.review}"
                </p>
              </div>
              
              <div className="border-t border-gray-200 pt-4">
                <p className="font-semibold text-gray-800">{review.name}</p>
                <p className="text-sm text-gray-500">{review.location}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="inline-flex items-center space-x-4 bg-amber-50 rounded-full px-8 py-4">
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="text-amber-400 fill-current" size={20} />
                ))}
              </div>
              <span className="text-xl font-bold text-gray-800">4.9</span>
            </div>
            <div className="text-gray-600">
              <span className="font-semibold">Based on 150+ reviews</span>
            </div>
          </div>
          <p className="mt-4 text-gray-600">
            Share your experience with us and help others discover Thai Riverside!
          </p>
        </div>
      </div>
    </section>
  );
};

export default Reviews;