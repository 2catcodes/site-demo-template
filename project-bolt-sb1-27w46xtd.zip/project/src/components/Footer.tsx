import React from 'react';
import { MapPin, Phone, Clock, Facebook, Instagram, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-amber-600 to-orange-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">TR</span>
              </div>
              <h3 className="text-2xl font-bold">Thai Riverside</h3>
            </div>
            <p className="text-gray-400 leading-relaxed mb-6">
              Kingsport's premier Thai restaurant offering authentic flavors in a beautiful riverside setting. Join us for an unforgettable dining experience.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 p-3 rounded-full hover:bg-amber-600 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="bg-gray-800 p-3 rounded-full hover:bg-amber-600 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="bg-gray-800 p-3 rounded-full hover:bg-amber-600 transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xl font-bold mb-6">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <MapPin className="text-amber-600" size={20} />
                <div>
                  <p>1837 Netherland Inn Road</p>
                  <p>Kingsport, TN 37660</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="text-amber-600" size={20} />
                <p>(423) 555-0123</p>
              </div>
              <div className="flex items-center space-x-3">
                <Clock className="text-amber-600" size={20} />
                <p>Open Tuesday - Sunday</p>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-xl font-bold mb-6">Hours</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Monday:</span>
                <span className="text-red-400">Closed</span>
              </div>
              <div className="flex justify-between">
                <span>Tue - Fri:</span>
                <span>11 AM - 2 PM, 4 - 8 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Saturday:</span>
                <span>11 AM - 3 PM, 5 - 8 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Sunday:</span>
                <span>11 AM - 3 PM</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Thai Riverside. All rights reserved. Made with ❤️ in Kingsport, TN.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;