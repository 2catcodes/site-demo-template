import React from 'react';
import { Truck, Clock, Phone } from 'lucide-react';

const Order = () => {
  return (
    <section id="order" className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Order Online
          </h2>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Craving Thai Riverside at home? Order online for pickup or delivery and enjoy our delicious food wherever you are.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="text-center">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Truck className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Fast Delivery</h3>
            <p className="text-white/90">
              Quick delivery to your door through our trusted partners
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Quick Pickup</h3>
            <p className="text-white/90">
              Order ahead and pick up at your convenience
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Phone Orders</h3>
            <p className="text-white/90">
              Call us directly for personalized service
            </p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
          <button className="bg-white text-amber-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors transform hover:scale-105 shadow-lg">
            Order on DoorDash
          </button>
          <button className="bg-white text-amber-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors transform hover:scale-105 shadow-lg">
            Order on Uber Eats
          </button>
          <button className="bg-white text-amber-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors transform hover:scale-105 shadow-lg">
            Call (423) 555-0123
          </button>
        </div>

        <div className="text-center mt-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-md mx-auto">
            <h4 className="text-lg font-semibold text-white mb-3">Delivery Hours</h4>
            <div className="space-y-2 text-white/90">
              <div className="flex justify-between">
                <span>Tuesday - Friday:</span>
                <span>11 AM - 8 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Saturday:</span>
                <span>11 AM - 8 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Sunday:</span>
                <span>11 AM - 3 PM</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Order;