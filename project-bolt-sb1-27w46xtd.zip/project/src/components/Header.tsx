import React, { useState } from 'react';
import { Menu, X, Phone, MapPin } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-amber-600 to-orange-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">TR</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Thai Riverside</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-amber-600 transition-colors">
              Home
            </button>
            <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-amber-600 transition-colors">
              About
            </button>
            <button onClick={() => scrollToSection('menu')} className="text-gray-700 hover:text-amber-600 transition-colors">
              Menu
            </button>
            <button onClick={() => scrollToSection('location')} className="text-gray-700 hover:text-amber-600 transition-colors">
              Location
            </button>
            <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-amber-600 transition-colors">
              Gallery
            </button>
            <button onClick={() => scrollToSection('reviews')} className="text-gray-700 hover:text-amber-600 transition-colors">
              Reviews
            </button>
            <button onClick={() => scrollToSection('order')} className="bg-amber-600 text-white px-6 py-2 rounded-full hover:bg-amber-700 transition-colors">
              Order Online
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-amber-600 transition-colors text-left">
                Home
              </button>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-amber-600 transition-colors text-left">
                About
              </button>
              <button onClick={() => scrollToSection('menu')} className="text-gray-700 hover:text-amber-600 transition-colors text-left">
                Menu
              </button>
              <button onClick={() => scrollToSection('location')} className="text-gray-700 hover:text-amber-600 transition-colors text-left">
                Location
              </button>
              <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-amber-600 transition-colors text-left">
                Gallery
              </button>
              <button onClick={() => scrollToSection('reviews')} className="text-gray-700 hover:text-amber-600 transition-colors text-left">
                Reviews
              </button>
              <button onClick={() => scrollToSection('order')} className="bg-amber-600 text-white px-6 py-2 rounded-full hover:bg-amber-700 transition-colors text-left">
                Order Online
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;