import React from 'react';
import { MapPin, Clock, Phone } from 'lucide-react';

const Location = () => {
  const hours = [
    { day: 'Monday', time: 'Closed', closed: true },
    { day: 'Tuesday - Friday', time: '11 AM - 2 PM, 4 - 8 PM', closed: false },
    { day: 'Saturday', time: '11 AM - 3 PM, 5 - 8 PM', closed: false },
    { day: 'Sunday', time: '11 AM - 3 PM', closed: false }
  ];

  return (
    <section id="location" className="py-20 bg-gradient-to-b from-blue-50 to-cyan-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Hours & Location
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Visit us at our scenic riverside location in Kingsport, Tennessee. We're easy to find and always happy to welcome you.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Location Info */}
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <MapPin className="text-amber-600" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-800">Address</h3>
                  <p className="text-gray-600">Find us along the scenic Holston River</p>
                </div>
              </div>
              <div className="text-lg text-gray-700 mb-4">
                1837 Netherland Inn Road<br />
                Kingsport, TN 37660
              </div>
              <button className="bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition-colors">
                Get Directions
              </button>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <Clock className="text-amber-600" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-800">Hours</h3>
                  <p className="text-gray-600">We're open most days of the week</p>
                </div>
              </div>
              <div className="space-y-3">
                {hours.map((schedule, index) => (
                  <div key={index} className={`flex justify-between items-center py-2 ${schedule.closed ? 'text-gray-500' : 'text-gray-700'}`}>
                    <span className="font-semibold">{schedule.day}</span>
                    <span className={schedule.closed ? 'text-red-500' : 'text-green-600'}>
                      {schedule.time}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <Phone className="text-amber-600" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-800">Contact</h3>
                  <p className="text-gray-600">Call us for reservations or questions</p>
                </div>
              </div>
              <div className="text-lg text-gray-700 mb-4">
                <a href="tel:+1423555-0123" className="hover:text-amber-600 transition-colors">
                  (423) 555-0123
                </a>
              </div>
            </div>
          </div>

          {/* Google Maps */}
          <div className="bg-white rounded-lg shadow-lg p-4">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3161.234!2d-82.5818!3d36.5484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x885a29b9c5d2b2a7%3A0x1234567890abcdef!2s1837%20Netherland%20Inn%20Rd%2C%20Kingsport%2C%20TN%2037660!5e0!3m2!1sen!2sus!4v1234567890123"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="rounded-lg"
              title="Thai Riverside Location"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Location;