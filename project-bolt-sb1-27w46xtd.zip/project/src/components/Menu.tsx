import React, { useState } from 'react';
import { ChefHat, Leaf, Star } from 'lucide-react';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('appetizers');

  const menuCategories = {
    appetizers: {
      name: 'Appetizers',
      items: [
        { name: 'Crab Rangoon', description: 'Crispy wontons filled with crab and cream cheese', price: '$8.95', spicy: false },
        { name: 'Fresh Spring Rolls', description: 'Rice paper rolls with shrimp, lettuce, and herbs', price: '$7.95', spicy: false },
        { name: 'Chicken Satay', description: 'Grilled skewers with peanut sauce and cucumber salad', price: '$9.95', spicy: false },
        { name: 'Thai Wings', description: 'Crispy wings tossed in sweet chili sauce', price: '$10.95', spicy: true }
      ]
    },
    soups: {
      name: 'Soups',
      items: [
        { name: 'Tom Yum Goong', description: 'Spicy and sour soup with shrimp, lemongrass, and lime', price: '$12.95', spicy: true },
        { name: 'Tom Kha Gai', description: 'Coconut chicken soup with galangal and mushrooms', price: '$11.95', spicy: false },
        { name: 'Wonton Soup', description: 'Traditional soup with pork and shrimp wontons', price: '$9.95', spicy: false }
      ]
    },
    noodles: {
      name: 'Noodles',
      items: [
        { name: 'Pad Thai', description: 'Classic stir-fried rice noodles with tamarind sauce', price: '$13.95', spicy: false, signature: true },
        { name: 'Drunken Noodles', description: 'Wide rice noodles with basil and chili', price: '$14.95', spicy: true, signature: true },
        { name: 'Pad See Ew', description: 'Sweet soy sauce noodles with broccoli and egg', price: '$13.95', spicy: false },
        { name: 'Lo Mein', description: 'Soft noodles stir-fried with vegetables and choice of protein', price: '$12.95', spicy: false }
      ]
    },
    curries: {
      name: 'Curries',
      items: [
        { name: 'Massaman Curry', description: 'Rich and creamy curry with potatoes and peanuts', price: '$15.95', spicy: true, signature: true },
        { name: 'Green Curry', description: 'Spicy green curry with Thai basil and eggplant', price: '$14.95', spicy: true },
        { name: 'Red Curry', description: 'Traditional red curry with bamboo shoots and bell peppers', price: '$14.95', spicy: true },
        { name: 'Panang Curry', description: 'Thick curry with kaffir lime leaves and peanuts', price: '$15.95', spicy: true }
      ]
    },
    stirfries: {
      name: 'Stir-Fries',
      items: [
        { name: 'Basil Fried Rice', description: 'Aromatic fried rice with Thai basil and chili', price: '$12.95', spicy: true, signature: true },
        { name: 'Pineapple Fried Rice', description: 'Sweet and savory fried rice served in a pineapple', price: '$16.95', spicy: false, signature: true },
        { name: 'Cashew Chicken', description: 'Stir-fried chicken with cashews and vegetables', price: '$14.95', spicy: false },
        { name: 'Thai Basil Stir-Fry', description: 'Spicy stir-fry with holy basil and chili', price: '$13.95', spicy: true }
      ]
    },
    specials: {
      name: 'Chef Specials',
      items: [
        { name: 'Shrimp Paradise', description: 'Signature shrimp dish with special sauce and vegetables', price: '$18.95', spicy: false, signature: true },
        { name: 'Chicken Fancy', description: 'Chef\'s special chicken preparation with exotic flavors', price: '$16.95', spicy: false, signature: true },
        { name: 'Mango Sticky Rice', description: 'Traditional Thai dessert with sweet coconut rice', price: '$7.95', spicy: false },
        { name: 'Thai Tea Crème Brûlée', description: 'Fusion dessert combining Thai tea and French technique', price: '$8.95', spicy: false }
      ]
    }
  };

  return (
    <section id="menu" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Our Menu
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Explore our carefully crafted selection of authentic Thai dishes, from traditional favorites to innovative chef specials.
          </p>
          <div className="flex items-center justify-center space-x-2 text-amber-600 mb-4">
            <Leaf size={20} />
            <span className="text-sm">Many dishes can be made vegan or vegetarian upon request</span>
          </div>
          <div className="text-sm text-gray-500">
            Spice levels available: 1 (mild) to 5 (very spicy)
          </div>
        </div>

        {/* Category Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {Object.entries(menuCategories).map(([key, category]) => (
            <button
              key={key}
              onClick={() => setActiveCategory(key)}
              className={`px-6 py-3 rounded-full font-semibold transition-all ${
                activeCategory === key
                  ? 'bg-amber-600 text-white shadow-lg transform scale-105'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Menu Items */}
        <div className="max-w-4xl mx-auto">
          <div className="grid gap-6">
            {menuCategories[activeCategory as keyof typeof menuCategories].items.map((item, index) => (
              <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center space-x-3">
                    <h3 className="text-xl font-bold text-gray-800">{item.name}</h3>
                    {item.signature && (
                      <div className="flex items-center space-x-1 bg-amber-100 text-amber-800 px-2 py-1 rounded-full text-xs">
                        <Star size={12} />
                        <span>Signature</span>
                      </div>
                    )}
                    {item.spicy && (
                      <div className="flex items-center space-x-1 bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">
                        <ChefHat size={12} />
                        <span>Spicy</span>
                      </div>
                    )}
                  </div>
                  <span className="text-xl font-bold text-amber-600">{item.price}</span>
                </div>
                <p className="text-gray-600 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Menu;